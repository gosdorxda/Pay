/**
 * Next.js instrumentation hook — runs once when the server starts.
 *
 * The scheduler (node-cron + drand + node:crypto/https) is Node-only and
 * cannot be bundled for the Edge runtime. We guard with `process.env.NEXT_RUNTIME`
 * so the scheduler is loaded exclusively in the Node.js runtime, and use a dynamic
 * `import()` so webpack does not pull those heavy dependencies into the Edge
 * instrumentation chunk (this is Next.js' documented pattern for instrumentation
 * hooks that rely on Node.js APIs).
 *
 * Note: in Next 16, `serverExternalPackages` (next.config.mjs) DOES externalize
 * packages for the instrumentation hook's Node runtime — `@prisma/client` /
 * `.prisma/client` are listed there so Prisma initializes at startup (without
 * it, the bundled client can't resolve the generated query engine and throws
 * "did not initialize yet"). The `NEXT_RUNTIME === "nodejs"` guard + dynamic
 * `import()` additionally keep node-cron / node:crypto / node:https out of the
 * Edge instrumentation chunk.
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    try {
      const { preferIpv4 } = await import("./lib/net-ipv4");
      if (await preferIpv4()) {
        console.log("[net] ipv4-first aktif, family auto-selection dimatikan");
      }
    } catch (e) {
      console.warn("[net] prefer-ipv4 tidak diterapkan:", (e as Error).message);
    }
    const { startScheduler } = await import("./lib/scheduler");
    await startScheduler();
  }
}


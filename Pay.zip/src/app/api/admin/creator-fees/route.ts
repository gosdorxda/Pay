import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin-guard";
import { getCreatorFeeStatus } from "@/lib/pumpfun/creator-fees";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/admin/creator-fees
 *
 * Claimable creator-fee status for the admin card: pumpdev balances, the
 * on-chain shareholder split, the platform wallet's SOL balance, the persisted
 * auto-claim toggle and the last few claim rows.
 */
export async function GET(request: NextRequest) {
  if (!isAdmin(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    return NextResponse.json(await getCreatorFeeStatus());
  } catch (e) {
    return NextResponse.json(
      { error: (e as Error).message },
      { status: 500 }
    );
  }
}
